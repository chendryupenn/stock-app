import React, {useContext} from 'react';
import {GlobalContext} from "./context/GlobalState";
import './Watchlist.css'

const WatchlistHome = () => {
  const {watchlist} = useContext(GlobalContext);


  return (
   <html>
    <body>
    
    <table className="watchlistTable">
      <caption><h1>Watchlist</h1></caption>
      <thead>
        <tr>
          <th>Company Name</th>
          <th>Price</th>
          <th>Percent Change</th>
        </tr>
      </thead>
      <tbody>
        {watchlist.map(item => (
          <tr key={item[0].symbol}>
            <td>{item[0].name}</td>
            <td>{item[0].price}</td>
            <td>{item[0].changesPercentage}</td>
          </tr>
        ))}
      </tbody>
    </table>

    </body>
  </html>
    
    
    
  )
}

export default WatchlistHome