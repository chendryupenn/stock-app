import React from 'react'
import Searchbar from './components/Searchbar.js'
import WatchlistHome from './WatchlistHome.js'

const Home = () => {
  return (
  <div>
    <div>
      <Searchbar />
    </div>
    <div>
      <WatchlistHome />
    </div>
  </div>
    
    
  )
}

export default Home