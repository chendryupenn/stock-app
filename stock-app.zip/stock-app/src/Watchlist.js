import React, {useContext, useState} from 'react';
import {GlobalContext} from "./context/GlobalState";
import './Watchlist.css'


const Watchlist = () => {
  const {removeStockFromWatchlist, watchlist} = useContext(GlobalContext);
  const [asc, setAsc] = useState(true)
  var copyList = [...watchlist];

  
    if(asc === true){
      copyList.sort((a, b) => {
        return a[0].price - b[0].price;
      });
      
    }else{
      copyList.sort((a, b) => {
       return b[0].price - a[0].price;
      });
      
    }
  
  

  return (
   
    <body>
    <button onClick={() => setAsc(!asc)}><h3>Sort by Price</h3></button>
    <table className="watchlistTable">
      <caption><h1>Watchlist</h1></caption>
      <thead>
        <tr>
          <th>Company Name</th>
          <th>Price</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {copyList.map(item => (
          <tr key={item[0].symbol}>
            <td>{item[0].name}</td>
            <td>{item[0].price}</td>
            <td><button onClick={() => removeStockFromWatchlist(item[0].symbol)}>Remove from Watchlist</button></td>
          </tr>
        ))}
      </tbody>
    </table>
    <script>
      
    </script>
    </body>
  
    
    
    
  )
}

export default Watchlist