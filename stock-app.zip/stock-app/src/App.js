import React from 'react'
import NavBar from './components/NavBar.js'
import Finances from './Finances.js'
import Watchlist from './Watchlist.js'
import Home from './Home.js'
import './App.css'
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import {GlobalProvider} from './context/GlobalState'

const App = () => {
  return (
    <GlobalProvider>
      <Router>
        <NavBar />
        <Routes>
            <Route path='/' element={<Home/>} />
            <Route path='/Finances' element={<Finances/>} />
            <Route path='/Watchlist' element={<Watchlist/>} />
        </Routes>
    </Router>
    </GlobalProvider>
    
      
        
    
  )
}

export default App