import React, {useState, useEffect } from 'react'
import axios from "axios";
import {Link} from "react-router-dom"

const Searchbar = () => {

    const [loading, setLoading] = useState(false);
    const [data, setData] = useState([]); 
    const [searchSymbol, setSearchSymbol] = useState("");

    const apiKey = '9835c581cfdf5f7833cb667c77c88435';

    useEffect(() => {
        const loadData = async() => {
            setLoading(true);
            const response = await axios.get(`https://financialmodelingprep.com/api/v3/stock/list?apikey=${apiKey}`);
            setData(response.data);
            setLoading(false);
        }

        loadData();
    }, [])
  return (
    <div className='SearchBar'>
        <h3>Search Companies</h3>
        <input
        type='text'
        placeholder='Search...'
        onChange={(e) => setSearchSymbol(e.target.value)}
        />
        {loading ? (<h4>Loading...</h4>): (
            data.filter((value) =>{
                if(searchSymbol === ""){
                    return value;
                } else if (value.name.toLowerCase().includes(searchSymbol.toLowerCase()) || value.symbol.toLowerCase().includes(searchSymbol.toLowerCase())){
                    return value;
                }

            }).map(item => <Link to="/Finances" state={item.symbol}> <h5 key={item.name}>{item.symbol} {item.name}</h5></Link>)
        )}
    </div>
  )
}

export default Searchbar