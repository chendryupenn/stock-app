import React, {useState, useEffect, useContext } from 'react'
import {GlobalContext} from './context/GlobalState';
import axios from "axios";
import {useLocation} from 'react-router-dom'
import Plot from 'react-plotly.js';
import "./Watchlist.css"

const Finances = () => {
  const {addStockToWatchlist, watchlist} = useContext(GlobalContext);
  const [xData, setXData] = useState([])
  const [yData, setYData] = useState([])
  const [data, setData] = useState([]); 
  const [watch, setWatch] = useState([{}]);
  var prices = {};
  const apiKey = '9835c581cfdf5f7833cb667c77c88435';
  const location = useLocation()
  const company_name = location.state === null ? "AAPL" : location.state;

  useEffect(() => {
      const loadData = async() => {
          const response = await axios.get(`https://financialmodelingprep.com/api/v3/income-statement/${company_name}?limit=5&apikey=${apiKey}`);
          setData(response.data);
      }

      loadData();
  }, []);
  
  useEffect(() => {
    const loadPrices = async() => {
        
        const response = await axios.get(`https://financialmodelingprep.com/api/v3/historical-price-full/${company_name}?serietype=line&apikey=${apiKey}`)
        
        
          prices = response.data;
          
          var x_data = []
          var y_data = []
          for(let i=0; i<prices.historical.length; i++){
            y_data.push(prices.historical[i].close)
            x_data.push(prices.historical[i].date)
          } 
          setXData(x_data);
          setYData(y_data);
        
       
    }
  
    loadPrices();
    
  }, []);
  
  useEffect(() => {
    const loadWatch = async() => {
        const response = await axios.get(`https://financialmodelingprep.com/api/v3/quote/${company_name}?apikey=${apiKey}`);
        setWatch(response.data);   
    }

    loadWatch();
  }, []); 
  
  let storedStock = watchlist.find(o => o[0].symbol === watch[0].symbol);
  const watchlistDisabled = storedStock ? true : false;

  return (
    <div>
      <h1>{company_name}</h1>

        <div>
          <button className='button' disabled={watchlistDisabled}
            onClick={() => {addStockToWatchlist(watch); console.log(watchlist)}}>Add to Watchlist</button>

        </div>

      <Plot data={[
            {
              x: xData,
              y: yData,
              type: 'scatter',
              mode: 'lines',
              marker: {color: 'red'},
            },
            {type: 'scatter', x: xData, y: yData},
          ]}
          layout={ {width: 600, height: 600, title: "Price (USD) vs. Time", showlegend: false} }/>
          
      <div>
          
            <table className="watchlistTable">
              <thead>
                <tr>
                  <th>Financial Annual Date</th>
                  <th>Revenue</th>
                  <th>Gross Profit</th>
                  <th>Earnings per Share</th>
                </tr>
              </thead>
              <tbody>
                {data.map(item => (
                <tr key={item.date}>
                  <td>{item.date}</td>
                  <td>{item.revenue.toLocaleString()}</td>
                  <td>{item.grossProfit.toLocaleString()}</td>
                  <td>{item.eps.toFixed(2)}</td>
                </tr>))}
              </tbody>
              </table>
      )
      </div>
      
    </div>
    
  )
}

export default Finances